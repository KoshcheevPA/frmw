import React from 'react';

export default function FrameworkInfo() {
  return (
    <>FrameworkInfo</>
  )
}