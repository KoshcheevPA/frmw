import React from 'react';
import QuizItem from "./QuizItem";
import QuizResult from "./QuizResult";

let data = [
  {
    q: 'Больше важна скорость работы приложения, или комплексное решение для разработки?',
    answers: [
      {text:'Скорость приложения', action: {react: 1, vue: 1.1}, form: "speed"},
      {text:'Комплексное решение', action: {angular: 1}, form: "speed"}]
  },
  {
    q: "Нужен ли Server Side Rendering? Планируется ли оптимизировать приложения для поисковиков (SEO)?",
    answers: [
      {text:'Да', action: {vue: 1.2, react: 1, angular: 1}, form: 'ssr'},
      {text:'Нет', action: {vue: 1, react: 1.2, angular: 1.2}, form: 'ssr'}
    ]
  },
  {
    q: "Важен ли вам уровень популярности фреймворка и размер его сообщества?",
    answers: [
      {text: 'Да', action: {react: 1.2}, form: "popular"},
      {text: 'Нет', action: {vue: 1, angular: 1}, form: "popular"}]
  },
  {
    q: "Вы хотите начать разработку в максимально короткие сроки?",
    answers: [
      {text:'Да', action: {vue: 1.1, react: 1}, form: "movefast"},
      {text:'Не имеет значения', action: {}, form: "movefast"}]
  },
  {
    q: 'Вы хотите ли вы решение "всё из коробки" или использовать богатый набор разных пакетов и библиотек?',
    answers: [
      {text:'Все из коробки', action: {angular: 1.3}, form: 'box'},
      {text:'Богатый набор пакетов и библиотек', action: {react: 1.3, vue: 1}, form: 'box'}
    ]
  },
  {
    q: 'Предварительный размер проекта?',
    answers: [
      {text:'Большой проект', action: {angular: 1.4, react: 1}, form: "size"},
      {text:'Проект среднего размера', action: {angular: 0.8, react: 1.4, vue: 1}, form: "size"},
      {text:'Маленький проект', action: {vue: 1.4, react: 1.2} ,form: "size"}]
  },
  {
    q: 'Ваш/командный уровень разработчиков',
    answers: [
      {text: 'Junior', action: {vue: 1.1, react: 1}, form: "level"},
      {text: 'Middle', action: {react: 1.2, vue: 1, angular: 1.1}, form: "level"},
      {text:'Senior', action: {angular: 1.2, vue: 1, react: 1}, form: "level"}]
  },
];

export default function Quiz() {
  const [result, setResult] = React.useState({});
  const [over, setOver] = React.useState(false);
  const [r, setR] = React.useState([{title: 'React', description: 'asdasd', percents: '75%'}]);

  const onItemCallback = (obj) => {
    setResult({...result, [obj.form]: obj.action})
  };
  const onSubmit = () => {
    console.log(result)
  };

  return (
    <>
      <div className='container align-items-start text-left mb-5 w-75 mt-3' style={{marginLeft: '0'}}>
        <h4 className={'text-left'} style={{marginLeft: '0', textAlign: 'left'}}>Опрос</h4>
        {data.map((el, index) => <QuizItem {...el} n={index + 1} nTotal={data.length} onItemCallback={onItemCallback}/>)}
        <button className={'btn btn-primary mt-5 d-flex mr-auto'} type={'button'} onClick={onSubmit} style={{marginLeft: '0'}}>Отправить</button>
      </div>
      <div className={'container d-flex'} style={{marginLeft: '0'}}>
        <QuizResult title={"React"} percents={'75%'} description={'ss'}/>
      </div>
    </>
  )
}