import React from 'react';

export default function QuizResult({percents, title, description, n}) {
  return (
    <div className={'container border border-light p-3 mb-3 rounded shadow'} style={{maxWidth: '650px'}}>
      {n}. {title} ({percents})
      <p>
        {description}
      </p>
    </div>
  )
}