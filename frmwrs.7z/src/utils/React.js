import React from 'react';

export const Description = () => {
  return <>Описание реакт</>
}